from a1 import HeapBase
# Problem a2: Heap Implementation


class Heap(HeapBase):
    # todo: implement this
    def add(self, value):
        pass

    # todo: implement this
    def remove_min(self):
        pass
