## Problem b1: Preorder Traversal


# todo: implement this
def preorder(tree):
    pass
