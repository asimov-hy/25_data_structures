from a2 import Heap
# Problem a3: Heap Sort


# todo: implement this
def heap_sort(arr):
    pass
