## Problem b3: Depth of a Node


# todo: implement this
def depth(tree, key):
    pass
