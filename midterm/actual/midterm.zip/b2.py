## Problem b2: Postorder Traversal


# todo: implement this
def postorder(tree):
    pass
