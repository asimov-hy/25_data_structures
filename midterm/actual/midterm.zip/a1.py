from a_skeleton import HeapSkeleton
# Problem a1: Up and Down


class HeapBase(HeapSkeleton):
    # todo: implement this
    def _upheap(self, j):
        pass
    
    # todo: implement this
    def _downheap(self, j):
        pass
