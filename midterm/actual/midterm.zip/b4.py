## Problem b4: Find Uncle


# todo: implement this
def uncle(tree, key):
    pass
