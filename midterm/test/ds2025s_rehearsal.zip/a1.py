## Problem a1: String reverse


def reverse(input_data):
    return input_data[::-1]
