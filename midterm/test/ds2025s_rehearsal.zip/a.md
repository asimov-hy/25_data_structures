# Rehearsal: String reverse

## Problem a1: String reverse

Implement the following function:

- `reverse(input_data: str) -> str`: This function takes a string `input_data` as input and returns the reversed string. For example, if the input is "hello", the output should be "olleh".
